import express from 'express'
import controller from './MvcControllers.js'
import MiddlewareHandler from '../../middlewares/MiddlewareHandler.js'


const mvcRouter = express.Router()

mvcRouter.get('/', 
  controller.getLanding)

mvcRouter.get('/detalles', 
  controller.getProduct)

mvcRouter.get('/detalles/:id',  
  MiddlewareHandler.middIntId('id'), 
  controller.getDetails)

mvcRouter.get('/detalles/item/:id', 
  MiddlewareHandler.middIntId('id'), 
  controller.getItems)

mvcRouter.get('/contacto', 
  controller.getContact)

mvcRouter.get('/acerca', 
  controller.getAbout);

mvcRouter.get('/videos/:id',
  controller.getVideos
)

mvcRouter.get('/login', 
  controller.getReact);

mvcRouter.get('/admin', 
  controller.getReact);

mvcRouter.get('/detalles/false', (req, res, next)=>{ //eslint-disable-line
        // res.status(404).send('Not Found')
         res.render('error', { message: 'Not Found', status: 404});
       });
      

export default mvcRouter;