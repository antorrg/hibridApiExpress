
import express from 'express'
import * as img from './utils/uploaderImgs.js'
import mvcRouter from './modules/mvcPages/mvc.routes.js';
import landRouter from './modules/landingPage/frontPage.routes.js'
import productRouter from './modules/productItems/product.routes.js'
import userRouter from './modules/users/user.routes.js'
import contactRouter from './modules/contacts/contac.routes.js';
import apiKeyRouter from './modules/apiKey/apiKey.routes.js';
import letterRouter from './modules/cartas/letter.routes.js';
import {verifyToken} from './utils/authConfig.js'


const mainRouter = express.Router()


mainRouter.use(mvcRouter)

mainRouter.use('/api/v1', userRouter)

mainRouter.use("/api/v1/", contactRouter)

mainRouter.use("/api/v1/apikey", apiKeyRouter)

mainRouter.use('/api/v1/letter', letterRouter)

mainRouter.post('/api/v1/uploadImage', verifyToken, img.uploadMiddleware, img.imageUploader )

mainRouter.use('/api/v1',  verifyToken, landRouter)

mainRouter.use('/api/v1', verifyToken, productRouter)


// Manejador de Rutas No Encontradas para MVC
mainRouter.use((req, res, next) => {
    if (req.originalUrl.startsWith('/api/v1/')) {
      // Si es una ruta de la API, pasa al siguiente middleware
      return next();
    }
    const err = new Error('Not Found');
    err.status = 404;
    next(err);
  });
  
  // Manejador de Errores para MVC
  mainRouter.use((err, req, res, next) => {
    if (req.originalUrl.startsWith('/api/v1/')) {
      // Si es una ruta de la API, pasa al siguiente middleware
      return next(err);
    }
    res.status(err.status || 400);
    res.render('error', { message: err.message, status: err.status || 500 });
  });
  
  // Manejador de Rutas No Encontradas para API REST
  mainRouter.use('/api/v1/*', (req, res, next) => {
    const err = new Error('Not Found');
    err.status = 404;
    next(err);
  });
  
  // Manejador de Errores para API REST
  mainRouter.use('/api/v1/*', (err, req, res, next) => {
    next(err)
  });
  



export default mainRouter; 
